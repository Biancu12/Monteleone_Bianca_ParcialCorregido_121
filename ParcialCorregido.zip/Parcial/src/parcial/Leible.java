package parcial;

public interface Leible {

    public void leer();
    
}
