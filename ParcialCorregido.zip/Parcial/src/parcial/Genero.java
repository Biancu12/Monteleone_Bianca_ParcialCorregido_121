package parcial;

public enum Genero {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA,
}
