package parcial;

import java.util.Objects;

public abstract class Publicacion {

    protected String titulo;
    protected int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        Publicacion other = (Publicacion) o;
        return titulo.equals(other.titulo) && anioPublicacion == other.anioPublicacion;
    }

}
