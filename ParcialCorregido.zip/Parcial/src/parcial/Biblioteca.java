package parcial;

import java.util.List;
import java.util.ArrayList;

public class Biblioteca {

    private List<Publicacion> publicaciones;

    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion publicacion) {
        if (publicaciones.contains(publicacion)) {
            throw new PublicacionRepetidaException();
        }
        publicaciones.add(publicacion);
    }

    public void mostrarPublicaciones() {
        System.out.println("Publicaciones en la biblioteca: ");
        for (Publicacion p : publicaciones) {
            System.out.println(p);
        }
    }

    public void leerPublicaciones() {
        System.out.println("Leyendo publicaciones: ");
        for (Publicacion p : publicaciones) {
            if (p instanceof Leible leible) {
                leible.leer();
            } else {
                System.out.println("La publicacion no es leible");
            }
        }
    }
}
