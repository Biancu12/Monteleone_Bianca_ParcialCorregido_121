package parcial;

public class Revista extends Publicacion implements Leible {

    private int nroEdicion;

    public Revista(String titulo, int anioPublicacion, int nroEdicion) {
        super(titulo, anioPublicacion);
        this.nroEdicion = nroEdicion;
    }

    @Override
    public void leer() {
        System.out.println("Leyendo la revista '" + titulo + "', nroEdicion: " + nroEdicion);
    }

    @Override
    public String toString() {
        return "Revista{" + "nroEdicion: " + nroEdicion + '}';
    }

}
