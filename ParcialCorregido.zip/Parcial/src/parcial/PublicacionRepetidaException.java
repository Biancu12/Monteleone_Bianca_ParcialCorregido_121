package parcial;

public class PublicacionRepetidaException extends RuntimeException {

    private final static String MESSAGE = "La publicacion ya se encuentra en la biblioteca";

    public PublicacionRepetidaException() {
        super(MESSAGE);
    }
    
}
