package parcial;

public class TestBiblioteca {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        try {
            biblioteca.agregarPublicacion(new Libro("El Principito", 1943, "Antoine de Saint-Exupery", Genero.FICCION));
            biblioteca.agregarPublicacion(new Libro("Breve historia del tiempo", 1988, "Stephen Hawking", Genero.CIENCIA));
            biblioteca.agregarPublicacion(new Revista("National Geographic", 2023, 132));
            biblioteca.agregarPublicacion(new Revista("Time", 2023, 45));
            biblioteca.agregarPublicacion(new Ilustracion("Guernica", 1937, "Pablo Picasso", 350, 780));
            biblioteca.agregarPublicacion(new Ilustracion("El Grito", 1893, "Edvard Munch", 91, 73));
            biblioteca.agregarPublicacion(new Ilustracion("El Grito", 1893, "Edvard Munch", 91, 73)); //Publicacion repetida
        } catch (PublicacionRepetidaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("..................................................................");

        biblioteca.mostrarPublicaciones();

        System.out.println("..................................................................");

        biblioteca.leerPublicaciones();
    }

}
